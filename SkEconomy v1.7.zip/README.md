SKEconomy
=========

SKEconomy is Skript based Economy for Minecraft with the objective of effectively 
integerating a wide range of Economic tools.


Installation
-------------------------------------

After installing and setting up craftbukkit:

1. Download the Skript.zip from http://dev.bukkit.org/server-mods/skript/files/

2. Extract into the bukkit plugins folder

3. Download skeconomy.zip from github or http://dev.bukkit.org/server-mods/my-scripts-njolbrims-skript/

4. Extract skeconomy.zip into plugins\Skript\scripts

We strongly suggest looking at the skripts for config options, available at the top of each script.


Issue Tracker & Suggestions
-------------

Please submit bug reports and feature requests for SkEconomy here:
https://github.com/SkCoding/SkEconomyDev/issues


Contributing
------------

We happily accept contributions. The best way to do this is to fork
WorldEdit on GitHub, add your changes, and then submit a pull request. We'll
look at it, make comments, and merge it into WorldEdit if everything
works out.

Your submissions have to be licensed under the GNU General Public License v3.